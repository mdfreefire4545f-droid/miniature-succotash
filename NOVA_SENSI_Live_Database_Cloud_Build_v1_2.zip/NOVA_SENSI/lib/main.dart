import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const NovaSensiApp());

const bg = Color(0xFF080B10), panel = Color(0xFF111821);
const red = Color(0xFFFF3155), cyan = Color(0xFF19D8E8);

class Phone {
  final String brand, model;
  final bool verified;
  Phone({required this.brand, required this.model, required this.verified});
  factory Phone.fromJson(Map<String, dynamic> j) => Phone(
    brand: j['brand'], model: j['model'], verified: j['verified'] ?? false);
}

class NovaSensiApp extends StatelessWidget {
  const NovaSensiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'NOVA SENSI',
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: red, secondary: cyan),
      useMaterial3: true, inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
    home: const HomePage());
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Phone> phones = [];
  List<String> brands = [];
  bool loading = true, customDevice = false;
  String? brand, model, style = 'Balanced', fingers = '4 Finger';
  final brandSearch = TextEditingController(), modelSearch = TextEditingController();
  final apiKeyController = TextEditingController(), onlineQueryController = TextEditingController();
  List<Map<String,dynamic>> onlineResults = [];
  bool searchingOnline = false;
  String onlineMessage = 'Connect a free Atlas API key to search the live phone catalog.';
  Map<String,int> result = {};
  String databaseStatus = 'Loading device catalog...';

  @override
  void initState() { super.initState(); loadPhones(); }
  @override
  void dispose() {
    brandSearch.dispose(); modelSearch.dispose();
    apiKeyController.dispose(); onlineQueryController.dispose();
    super.dispose();
  }

  Future<void> searchOnline() async {
    final key = apiKeyController.text.trim();
    final query = onlineQueryController.text.trim();
    if (key.isEmpty || query.isEmpty) {
      setState(() => onlineMessage = 'Enter your Atlas API key and a brand/model name.');
      return;
    }
    setState(() { searchingOnline = true; onlineResults = []; onlineMessage = 'Searching live database...'; });
    try {
      final uri = Uri.https('api.devicedatabase.org', '/v1/devices',
        {'q': query, 'department': 'phones', 'limit': '30'});
      final response = await http.get(uri, headers: {'Authorization': 'Bearer $key'})
        .timeout(const Duration(seconds: 18));
      if (response.statusCode == 200) {
        final body = jsonDecode(response.body) as Map<String,dynamic>;
        final rows = (body['data'] as List? ?? []).cast<Map<String,dynamic>>();
        setState(() {
          onlineResults = rows;
          onlineMessage = rows.isEmpty ? 'No matching phone found. Try another spelling or use Custom Model.' :
            '${rows.length} live result(s) found. Select a phone below.';
        });
      } else if (response.statusCode == 401) {
        setState(() => onlineMessage = 'API key rejected. Check your live key in Atlas account.');
      } else if (response.statusCode == 429) {
        setState(() => onlineMessage = 'API limit reached. Wait for quota reset or check your free plan.');
      } else {
        setState(() => onlineMessage = 'Live service error (${response.statusCode}). Try again later.');
      }
    } catch (_) {
      setState(() => onlineMessage = 'Could not reach the live service. Check internet and try again.');
    } finally {
      if (mounted) setState(() => searchingOnline = false);
    }
  }

  void selectOnlinePhone(Map<String,dynamic> item) {
    final b = (item['brand'] as Map<String,dynamic>?)?['name']?.toString() ?? 'Unknown Brand';
    final m = item['name']?.toString() ?? 'Unknown Model';
    setState(() {
      brand = b; model = m; customDevice = false; result.clear();
      brandSearch.text = b; modelSearch.text = m;
      onlineMessage = 'Selected from live catalog. Device specs are sourced; sensitivity remains a starting preset.';
    });
  }

  Future<void> loadPhones() async {
    final raw = await rootBundle.loadString('assets/data/phones.json');
    final decoded = (jsonDecode(raw) as List).map((e) => Phone.fromJson(e)).toList();
    setState(() {
      phones = decoded;
      brands = decoded.map((e) => e.brand).toSet().toList()..sort();
      loading = false;
      databaseStatus = '${phones.length} catalog entries • ${brands.length} brands';
    });
  }

  List<String> get filteredBrands => brands.where((b) =>
    b.toLowerCase().contains(brandSearch.text.trim().toLowerCase())).toList();
  List<String> get filteredModels {
    if (brand == null) return [];
    return phones.where((p) => p.brand == brand && p.model.toLowerCase()
      .contains(modelSearch.text.trim().toLowerCase())).map((p)=>p.model).toSet().toList()..sort();
  }

  void chooseBrand(String value) => setState(() {
    brand=value; model=null; customDevice=false; modelSearch.clear(); result.clear();
  });
  void chooseModel(String value, {bool custom=false}) => setState(() {
    model=value; customDevice=custom; result.clear();
  });

  void generate() {
    if ((brandSearch.text.trim().isNotEmpty && brand == null) ||
        (brand == null) || (model == null || model!.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Brand এবং Model নির্বাচন বা লিখুন')));
      return;
    }
    // Generic starting presets only. They are not device-tested or guaranteed.
    final base = style == 'Fast Drag' ? 190 : style == 'Precision' ? 165 : 180;
    final adj = fingers == '2 Finger' ? -5 : fingers == '3 Finger' ? 0 : 3;
    setState(() => result = {
      'General': (base+adj).clamp(0,200), 'Red Dot': (base-5+adj).clamp(0,200),
      '2X Scope': (base-12+adj).clamp(0,200), '4X Scope': (base-22+adj).clamp(0,200),
      'Sniper Scope': 90, 'Free Look': 150,
    });
  }
  int fireSize() => fingers == '2 Finger' ? 52 : fingers == '3 Finger' ? 48 : 45;

  Future<void> copyAll() async {
    final s = 'NOVA SENSI | $brand $model\n${result.entries.map((e)=>'${e.key}: ${e.value}').join('\n')}\nFire Button: ${fireSize()}%\nDPI: Keep device default initially.\nStatus: ${customDevice ? 'Unverified custom device' : 'Starting recommendation, not device-tested'}';
    await Clipboard.setData(ClipboardData(text:s));
    if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Settings copied!')));
  }

  Widget heading(String s, IconData icon) => Padding(
    padding: const EdgeInsets.only(top:19,bottom:10),
    child: Row(children:[Icon(icon,color:cyan,size:19),const SizedBox(width:8),
      Text(s,style:const TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.1))]));
  Widget field(String label, TextEditingController c, ValueChanged<String> onChanged, {String hint=''}) =>
    TextField(controller:c,onChanged:onChanged,decoration:InputDecoration(
      labelText:label,hintText:hint,prefixIcon:const Icon(Icons.search,color:cyan),
      suffixIcon:c.text.isEmpty?null:IconButton(icon:const Icon(Icons.close),onPressed:(){c.clear();onChanged('');})));
  Widget choiceChip(String label, bool selected, VoidCallback tap) => Padding(
    padding: const EdgeInsets.only(right:7,bottom:7),
    child: ChoiceChip(label:Text(label),selected:selected,onSelected:(_)=>tap(),
      selectedColor:red.withOpacity(.25),side:BorderSide(color:selected?red:Colors.white12)));
  Widget _metric(String t,String v,Color c)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(t,style:const TextStyle(color:Colors.white54,fontSize:9,letterSpacing:1)),
    const SizedBox(height:4),Text(v,style:TextStyle(color:c,fontSize:20,fontWeight:FontWeight.w900))]);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar:AppBar(backgroundColor:bg,title:const Row(children:[
      Icon(Icons.bolt,color:red,size:27),SizedBox(width:6),
      Text('NOVA ',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2)),
      Text('SENSI',style:TextStyle(color:cyan,fontWeight:FontWeight.w900,letterSpacing:2))]),
      actions:[IconButton(icon:const Icon(Icons.info_outline,color:cyan),onPressed:()=>showAboutDialog(
        context:context,applicationName:'NOVA SENSI',applicationVersion:'1.1.0',
        children:const[Text('Community-maintained device catalog. Recommendations are not guaranteed or affiliated with Garena.')]))]),
    body:loading?const Center(child:CircularProgressIndicator(color:cyan)):ListView(
      padding:const EdgeInsets.fromLTRB(18,8,18,30),children:[
        Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Color(0xFF28101A),Color(0xFF10232B)]),
          border:Border.all(color:red.withOpacity(.45))),
          child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('UNIVERSAL DEVICE SEARCH',style:TextStyle(color:cyan,fontSize:10,letterSpacing:2,fontWeight:FontWeight.bold)),
            SizedBox(height:10),Text('FIND YOUR\\nPERFECT SENSI',style:TextStyle(fontSize:27,height:1.05,fontWeight:FontWeight.w900)),
            SizedBox(height:8),Text('Search a catalog phone or enter a missing model.',style:TextStyle(color:Colors.white70,fontSize:12))])),
        heading('SEARCH BRAND',Icons.public),
        field('Type brand name',brandSearch,(v)=>setState((){}),hint:'e.g. Samsung, Xiaomi, Apple'),
        if(brandSearch.text.isNotEmpty && brand==null)
          Wrap(children:filteredBrands.take(30).map((b)=>choiceChip(b,false,()=>chooseBrand(b))).toList()),
        if(brand!=null) ...[
          const SizedBox(height:8),
          Row(children:[Expanded(child:Text('Selected brand: $brand',style:const TextStyle(color:cyan,fontWeight:FontWeight.bold))),
            TextButton(onPressed:()=>setState(() {
              brand=null; model=null; result.clear();
              brandSearch.clear(); modelSearch.clear();
            }),child:const Text('Change'))]),
        ],
        if(brand==null) ...[
          heading('POPULAR BRANDS',Icons.devices),
          Wrap(children:brands.take(18).map((b)=>choiceChip(b,false,()=>{chooseBrand(b),brandSearch.text=b})).toList()),
        ],
        if(brand!=null) ...[
          heading('SEARCH PHONE MODEL',Icons.phone_android),
          field('Type model name',modelSearch,(v)=>setState((){}),hint:'Search all listed models'),
          if(modelSearch.text.isNotEmpty)
            Wrap(children:filteredModels.take(40).map((m)=>choiceChip(m,model==m,()=>chooseModel(m))).toList())
          else
            Wrap(children:filteredModels.take(24).map((m)=>choiceChip(m,model==m,()=>chooseModel(m))).toList()),
          if(model!=null) Padding(padding:const EdgeInsets.only(top:6),child:Text('Selected model: $model${customDevice?' • Custom / unverified':''}',style:const TextStyle(color:cyan))),
          if(modelSearch.text.trim().isNotEmpty && !filteredModels.any((m)=>m.toLowerCase()==modelSearch.text.trim().toLowerCase()))
            Container(margin:const EdgeInsets.only(top:10),padding:const EdgeInsets.all(12),
              decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(12),border:Border.all(color:cyan.withOpacity(.35))),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const Text('MODEL NOT FOUND?',style:TextStyle(color:cyan,fontWeight:FontWeight.bold)),
                const SizedBox(height:5),Text('Use "${modelSearch.text.trim()}" as a custom model. Its recommendation will be marked unverified.',style:const TextStyle(color:Colors.white70,fontSize:12)),
                TextButton.icon(onPressed:()=>chooseModel(modelSearch.text.trim(),custom:true),icon:const Icon(Icons.add),label:const Text('USE THIS CUSTOM MODEL'))])),
        ],
        heading('LIVE INTERNET PHONE DATABASE',Icons.cloud_sync),
        const Text('Powered by Techfleet Atlas • Free plan: up to 10,000 requests/month.',style:TextStyle(color:Colors.white60,fontSize:11)),
        const SizedBox(height:9),
        TextField(controller:apiKeyController,obscureText:true,decoration:const InputDecoration(
          labelText:'Atlas API key',hintText:'atlas_live_…',prefixIcon:Icon(Icons.key,color:cyan))),
        const SizedBox(height:9),
        TextField(controller:onlineQueryController,decoration:const InputDecoration(
          labelText:'Search any phone online',hintText:'e.g. Samsung Galaxy S25 Ultra',prefixIcon:Icon(Icons.travel_explore,color:cyan))),
        const SizedBox(height:9),
        SizedBox(height:46,child:OutlinedButton.icon(
          onPressed:searchingOnline?null:searchOnline,
          icon:searchingOnline?const SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.search,color:cyan),
          label:Text(searchingOnline?'SEARCHING...':'SEARCH LIVE DATABASE',style:const TextStyle(color:cyan,fontWeight:FontWeight.bold)),
          style:OutlinedButton.styleFrom(side:const BorderSide(color:cyan)))),
        Padding(padding:const EdgeInsets.only(top:8),child:Text(onlineMessage,style:const TextStyle(color:Colors.white60,fontSize:11))),
        if(onlineResults.isNotEmpty)
          Container(margin:const EdgeInsets.only(top:8),padding:const EdgeInsets.all(10),
            decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(12)),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              ...onlineResults.map((item){
                final b=(item['brand'] as Map<String,dynamic>?)?['name']?.toString()??'Unknown';
                final n=item['name']?.toString()??'Unknown model';
                return ListTile(dense:true,contentPadding:EdgeInsets.zero,
                  leading:const Icon(Icons.phone_android,color:cyan),
                  title:Text(n,style:const TextStyle(fontWeight:FontWeight.bold)),
                  subtitle:Text(b,style:const TextStyle(color:Colors.white54,fontSize:11)),
                  trailing:const Icon(Icons.add_circle_outline,color:red),
                  onTap:()=>selectOnlinePhone(item));
              }),
            ])),
        const SizedBox(height:8),
        const Text('Get your own free API key: devicedatabase.org/account. Keep the key private. This app uses it directly on your phone; do not publish an APK containing a shared team key.',style:TextStyle(color:Colors.white38,fontSize:10,height:1.4)),
        heading('GAMEPLAY PROFILE',Icons.sports_esports),
        DropdownButtonFormField<String>(value:style,decoration:const InputDecoration(labelText:'Sensitivity style'),
          items:['Balanced','Fast Drag','Precision'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>style=v!)),
        const SizedBox(height:11),
        DropdownButtonFormField<String>(value:fingers,decoration:const InputDecoration(labelText:'HUD finger layout'),
          items:['2 Finger','3 Finger','4 Finger'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>fingers=v!)),
        const SizedBox(height:17),
        SizedBox(height:53,child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:red),
          onPressed:generate,icon:const Icon(Icons.auto_awesome),label:const Text('GENERATE MY SENSITIVITY',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:1)))),
        if(result.isNotEmpty)...[
          heading('YOUR CONFIGURATION',Icons.bolt),
          Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(18),border:Border.all(color:cyan.withOpacity(.35))),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text('$brand • $model',style:const TextStyle(color:cyan,fontWeight:FontWeight.bold)),
              const SizedBox(height:6),
              Container(padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:Colors.orange.withOpacity(.10),borderRadius:BorderRadius.circular(8)),
                child:Text(customDevice?'UNVERIFIED GENERIC STARTING PRESET':'STARTING PRESET • NOT DEVICE-TESTED',style:const TextStyle(color:Colors.orangeAccent,fontSize:10,fontWeight:FontWeight.bold))),
              const SizedBox(height:12),
              ...result.entries.map((e)=>Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Row(children:[
                Expanded(child:Text(e.key,style:const TextStyle(color:Colors.white70))),
                SizedBox(width:100,child:LinearProgressIndicator(value:e.value/200,minHeight:6,color:e.key=='General'?red:cyan,backgroundColor:Colors.white12)),
                const SizedBox(width:12),SizedBox(width:28,child:Text('${e.value}',textAlign:TextAlign.end,style:const TextStyle(fontWeight:FontWeight.bold)))]))),
              const Divider(color:Colors.white12,height:24),
              Row(children:[Expanded(child:_metric('FIRE BUTTON','${fireSize()}%',red)),Expanded(child:_metric('DPI','DEFAULT',cyan))]),
              const SizedBox(height:10),
              const Text('DPI: The app cannot reliably infer or safely set a universal DPI. Keep the phone default initially. Fire button and sensitivity are starting points; test in Training Ground.',style:TextStyle(fontSize:11,color:Colors.white60,height:1.4)),
              const SizedBox(height:12),
              SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:copyAll,icon:const Icon(Icons.copy,color:cyan),label:const Text('COPY ALL SETTINGS',style:TextStyle(color:cyan,fontWeight:FontWeight.bold))))
            ])),
          const Padding(padding:EdgeInsets.only(top:12),child:Text('Tune gradually. Results vary with game version, screen/touch response, screen protector and player preference.',style:TextStyle(color:Colors.white54,fontSize:11,height:1.45))),
        ],
        heading('PHONE DATABASE',Icons.storage),
        Text(databaseStatus,style:const TextStyle(color:Colors.white60,fontSize:12)),
        const SizedBox(height:6),
        const Text('Local list is a fallback. Use Live Internet Phone Database above to search the connected catalog, or Custom Model when a phone is still missing.',style:TextStyle(color:Colors.white38,fontSize:11,height:1.4)),
        const SizedBox(height:18),
        const Center(child:Text('NOVA SENSI • BUILT FOR YOUR GAME',style:TextStyle(color:Colors.white30,fontSize:10,letterSpacing:1.2))),
      ]));
}
