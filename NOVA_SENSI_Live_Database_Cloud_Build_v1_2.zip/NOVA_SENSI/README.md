# NOVA SENSI 1.2 — Live database + mobile cloud build

## New
- Live phone search through Techfleet Atlas API
- API key field in the app (key is entered by the user; not hardcoded)
- Search results can be selected into the device profile
- Local starter catalog remains as fallback
- GitHub Actions workflow builds the APK in the cloud

## Live database setup
1. Create a free account at https://devicedatabase.org/account
2. Create a live API key (starts with `atlas_live_`).
3. Open NOVA SENSI and paste the key in the Atlas API key field.
4. Search by brand or phone model.
The Atlas Free plan documents 10,000 requests/month. The live catalog is external and may be updated or temporarily unavailable. This app only uses phone catalog data; it does not provide verified Free Fire sensitivity values.

**Security:** this version keeps the key in the app's text field for the current session and sends it directly to Atlas. Do not share your key or publish an APK with a shared key. For a public app, put the API key behind your own backend.

## Build without a computer (Android phone + browser)
This project includes `.github/workflows/build-apk.yml`.
1. Download and extract the ZIP on your Android phone.
2. Sign in to GitHub in your mobile browser and create a new empty repository.
3. Upload the extracted project files and folders to the repository root (including the hidden `.github/workflows/build-apk.yml` folder).
4. Open the repository's **Actions** tab. Enable Actions if GitHub asks.
5. Run **Build NOVA SENSI APK** (or wait for the push-triggered build).
6. Open the completed workflow run, find **Artifacts**, and download `NOVA-SENSI-APK`.
7. Extract the artifact ZIP and install `app-release.apk`.

GitHub's web interface on mobile can be awkward for uploading many nested files. If it does not let you upload the `.github` folder, create the workflow file manually in GitHub using the path `.github/workflows/build-apk.yml`, then paste the workflow contents from this project.

## Build on a computer
```bash
flutter create . --platforms=android
flutter pub get
flutter build apk --release
```

## Accuracy
Sensitivity and fire-button values are generic starting presets, not device-tested guarantees. DPI remains at the phone default; the app does not change Android system settings. A device specification database cannot supply a player's proven Free Fire sensitivity. Verified profiles require real gameplay testing for each device/game version/control setup.
